package es.ucm.gdv.practica1.engine;

public class FloatPair {
    public FloatPair(float x, float y){
        _x = x;
        _y = y;
    }
    public float _x;
    public float _y;

}
